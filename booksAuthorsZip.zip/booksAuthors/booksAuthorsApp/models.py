from django.db import models

class addBookMan(models.Manager):
    def basicValidator(self, postData):
        errors = {}
        if len(postData["title"]) < 4:
            errors["title"] = "Book Title should be at least 4 characters!!!"
        if len(postData["desc"]) < 7:
            errors["desc"] = "Book description should be at least 7 characters!!!"
        return errors

# class editBookMan(models.Manager):
#     def basicValidator(self, postData):
#         errors = {}
#         if len(postData["title"]) < 4:
#             errors["title"] = "Book Title should be at least 4 characters!!!"
#         if len(postData["desc"]) < 7:
#             errors["desc"] = "Book description should be at least 7 characters!!!"
#         return errors

class Authors(models.Model):
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    notes = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __repr__(self):
        return f"<{self.first_name} {self.id}>"

class Books(models.Model):
    title = models.CharField(max_length=255)
    desc = models.TextField()
    authors = models.ManyToManyField(Authors, related_name="books")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = addBookMan()

    def __repr__(self):
        return f"<{self.title} {self.id}>"

# Create your models here.
