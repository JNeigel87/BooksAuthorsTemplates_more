from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Authors, Books


def index(request):
    context = {
        "all_the_books": Books.objects.all(),
        
    }
    
    return render(request, "main.html", context)

def create(request):
    errors = Books.objects.basicValidator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    # print(request.POST)
    else:
        Books.objects.create(
            title=request.POST["title"],
            desc=request.POST["desc"],
        )
        return redirect("/")

def info(request, booksid):
    print(request.POST)
    context = {
        "book": Books.objects.get(id = booksid),
        # "authors": books.authors.get(id = booksid),
        "author": Authors.objects.all()
    }
    return render(request, "books.html", context)

def addAuthor(request, booksid):
    book = Books.objects.get(id=booksid)
    author = Authors.objects.get(id=request.POST['authorinfo'])
    book.authors.add(author)
    return redirect(f"/books/{booksid}")

def delete(request, booksid):
    thatBook = Books.objects.get(id=booksid)
    thatBook.delete()
    return redirect("/")

def bookEdit(request, booksid):
    context = {
        "book": Books.objects.get(id = booksid),
        "author": Authors.objects.all()
    }
    return render(request, "updatebook.html", context)

def updateBook(request, booksid):
    errors = Books.objects.basicValidator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f"/editBook/{booksid}")
    # print(request.POST)
    else:
        thisBook = Books.objects.get(id=booksid)
        thisBook.title = request.POST["title"]
        thisBook.desc = request.POST["desc"]
        thisBook.save()
        return redirect("/")

def deleteAuthor(request, booksid):
    book = Books.objects.get(id=booksid)
    author = Authors.objects.get(id=request.POST['authorinfo'])
    book.authors.remove(author)
    return redirect(f"/books/{booksid}")




# Create your views here.
